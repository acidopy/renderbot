# Bot de Arbitraje para Render

Este bot de Telegram consulta datos de Bybit y está listo para ejecutarse 24/7 en Render.

## ¿Cómo desplegar?

1. Subí este proyecto a un repositorio en GitHub
2. Andá a [https://render.com](https://render.com)
3. Clic en "New" > "Web Service" > "Import from GitHub"
4. Render detectará `render.yaml` y configurará todo automáticamente
5. ¡Listo! El bot estará corriendo

No necesitás configurar variables, ya están en `.env` incluido.
